
const form = document.querySelector("form");
const tableBody = document.querySelector("tbody");

form.addEventListener("submit", function (event) {
  event.preventDefault(); 

  const nombre = document.getElementById("nombre").value;
  const dosis = document.getElementById("dosis").value;
  const frecuencia = document.getElementById("frecuencia").value;
  const fecha = document.getElementById("fecha").value;

  const fila = document.createElement("tr");
  fila.innerHTML = `
    <td>${nombre}</td>
    <td>${dosis}</td>
    <td>${frecuencia}</td>
    <td>${fecha}</td>
  `;

  tableBody.appendChild(fila);


  form.reset();
});
